"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { supabase }   from "@/lib/supabase";
import { useTenant }  from "@/lib/hooks/useTenant";
import SpotlightOfMonthBanner from "@/app/dashboard/components/SpotlightOfMonthBanner";
import ReportAIContent from "@/app/dashboard/components/ai/ReportAIContent";
import {
  PieChart, Pie, Cell, ResponsiveContainer,
  AreaChart, Area, XAxis, YAxis, Tooltip,
} from "recharts";
import {
  Brain, TrendingUp, TrendingDown, Users,
  Clock, ShieldCheck, Zap, Activity,
  AlertTriangle, CheckCircle2, ArrowUpRight,
  ArrowDownRight, Minus, RefreshCw, Loader2,
  Briefcase, Target, Award, BarChart3,
} from "lucide-react";

// ─────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────
interface Metrics {
  applied:              number;
  screening:            number;
  interview:            number;
  offer:                number;
  hired:                number;
  rejected:             number;
  onboarding:           number;
  openTasks:            number;
  activeIncidents:      number;
  spotlightsThisMonth:  number;
  complianceRate:       number;
  avgScore:             number;
  conversionRate:       number;
  dropoffRate:          number;
  hiringEfficiency:     number;
  automationCoverage:   number | null;
  costSaved:            number | null;
  systemHealth:         string;
  timeToHire:           { current: number | null; sampleSize: number };
  funnel:               { applied: number; screening: number; interview: number; offer: number; hired: number };
  deptDistribution:     { name: string; value: number }[];
  topRoles:             { name: string; value: number }[];
  trends:               { applications: number[]; hires: number[] };
  insights:             { type: string; severity: string; message: string }[];
  generatedAt:          string;
}

// ─────────────────────────────────────────
// COLORS
// ─────────────────────────────────────────
const DEPT_COLORS  = ["#4ade80","#818cf8","#f59e0b","#ec4899","#14b8a6","#f97316","#8b5cf6","#06b6d4"];
const SEVERITY_CFG: Record<string, { cls: string; dot: string }> = {
  success: { cls: "text-emerald-400", dot: "bg-emerald-400" },
  warning: { cls: "text-amber-400",   dot: "bg-amber-400"   },
  alert:   { cls: "text-red-400",     dot: "bg-red-400"     },
  info:    { cls: "text-indigo-400",  dot: "bg-indigo-400"  },
};

function timeAgo(iso: string) {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60)   return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  return `${Math.floor(s / 3600)}h ago`;
}

// ─────────────────────────────────────────
// CHART MOUNT GUARD
// Prevents Recharts rendering before container has real dimensions
// ─────────────────────────────────────────
function ChartReady({ children, height }: { children: React.ReactNode; height: number }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const id = requestAnimationFrame(() => setReady(true));
    return () => cancelAnimationFrame(id);
  }, []);

  if (!ready) return <div style={{ height }} />;
  return <>{children}</>;
}

// ─────────────────────────────────────────
// ANIMATED COUNTER
// ─────────────────────────────────────────
function AnimatedNumber({ value, prefix = "", suffix = "", decimals = 0 }: {
  value: number; prefix?: string; suffix?: string; decimals?: number;
}) {
  const [display, setDisplay] = useState(0);
  const raf = useRef<number | undefined>(undefined);

  useEffect(() => {
    const start = display;
    const end   = value;
    const dur   = 800;
    const t0    = performance.now();
    const tick  = (now: number) => {
      const p    = Math.min((now - t0) / dur, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      setDisplay(start + (end - start) * ease);
      if (p < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => { if (raf.current) cancelAnimationFrame(raf.current); };
  }, [value]);

  return (
    <span>
      {prefix}{decimals > 0 ? display.toFixed(decimals) : Math.round(display)}{suffix}
    </span>
  );
}

// ─────────────────────────────────────────
// KPI CARD
// ─────────────────────────────────────────
function KPICard({
  label, value, sub, icon: Icon, color, trend, prefix = "", suffix = "", decimals = 0,
}: {
  label:     string;
  value:     number;
  sub:       string;
  icon:      React.ElementType;
  color:     string;
  trend?:    "up" | "down" | "flat";
  prefix?:   string;
  suffix?:   string;
  decimals?: number;
}) {
  const TrendIcon = trend === "up" ? ArrowUpRight : trend === "down" ? ArrowDownRight : Minus;
  const trendCls  = trend === "up" ? "text-emerald-400" : trend === "down" ? "text-red-400" : "text-zinc-600";

  return (
    <div className="group rounded-2xl border border-zinc-800 bg-zinc-900 p-5 hover:border-zinc-700 transition-all duration-200">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${color}`}>
          <Icon size={16} className="text-white" />
        </div>
        <TrendIcon size={14} className={trendCls} />
      </div>
      <p className="text-2xl font-bold text-white tracking-tight">
        <AnimatedNumber value={value} prefix={prefix} suffix={suffix} decimals={decimals} />
      </p>
      <p className="text-xs font-medium text-white/70 mt-0.5">{label}</p>
      <p className="text-[10px] text-zinc-600 mt-0.5">{sub}</p>
    </div>
  );
}

// ─────────────────────────────────────────
// XAVIER ANALYTICS STRIP
// ─────────────────────────────────────────
function XavierStrip({ m }: { m: Metrics }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 rounded-2xl border border-indigo-500/20 bg-indigo-500/[0.04]">
      {/* Hiring Efficiency */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] text-zinc-500">Hiring Efficiency</span>
          <span className={`text-xs font-bold ${m.hiringEfficiency >= 80 ? "text-emerald-400" : m.hiringEfficiency >= 60 ? "text-amber-400" : "text-red-400"}`}>
            {m.hiringEfficiency}%
          </span>
        </div>
        <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-1000 ${m.hiringEfficiency >= 80 ? "bg-emerald-500" : m.hiringEfficiency >= 60 ? "bg-amber-500" : "bg-red-500"}`}
            style={{ width: `${m.hiringEfficiency}%` }}
          />
        </div>
      </div>


      {/* Compliance Rate */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] text-zinc-500">Compliance Rate</span>
          <span className={`text-xs font-bold ${m.complianceRate >= 70 ? "text-emerald-400" : "text-amber-400"}`}>
            {m.complianceRate}%
          </span>
        </div>
        <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-1000 ${m.complianceRate >= 70 ? "bg-emerald-500" : "bg-amber-500"}`}
            style={{ width: `${m.complianceRate}%` }}
          />
        </div>
      </div>

      {/* Avg Score */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] text-zinc-500">Avg Xavier Score</span>
          <span className={`text-xs font-bold ${m.avgScore >= 70 ? "text-emerald-400" : m.avgScore >= 50 ? "text-amber-400" : "text-zinc-500"}`}>
            {m.avgScore > 0 ? `${m.avgScore}/100` : "—"}
          </span>
        </div>
        <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-1000 ${m.avgScore >= 70 ? "bg-emerald-500" : m.avgScore >= 50 ? "bg-amber-500" : "bg-zinc-700"}`}
            style={{ width: `${m.avgScore}%` }}
          />
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// FUNNEL BAR
// ─────────────────────────────────────────
function FunnelBar({ label, value, max, color }: {
  label: string; value: number; max: number; color: string;
}) {
  const pct     = max > 0 ? (value / max) * 100 : 0;
  const dropoff = max > 0 && value < max ? Math.round(((max - value) / max) * 100) : 0;

  return (
    <div className="mb-3 last:mb-0">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-zinc-400">{label}</span>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-white">{value}</span>
          {dropoff > 0 && <span className="text-[10px] text-red-400/70">-{dropoff}%</span>}
        </div>
      </div>
      <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all duration-1000 ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// CUSTOM TOOLTIP
// ─────────────────────────────────────────
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2 shadow-xl">
      {label && <p className="text-[10px] text-zinc-500 mb-1">{label}</p>}
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-xs font-medium" style={{ color: p.color }}>{p.name}: {p.value}</p>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────
// MINI SPARKLINE
// ─────────────────────────────────────────
function Sparkline({ data, color }: { data: number[]; color: string }) {
  const chartData = data.map((v, i) => ({ i, v }));
  const [ready, setReady] = useState(false);
  useEffect(() => { const id = requestAnimationFrame(() => setReady(true)); return () => cancelAnimationFrame(id); }, []);
  if (!ready) return <div style={{ height: 48 }} />;
  return (
    <ResponsiveContainer width="100%" height={48}>
      <AreaChart data={chartData} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={`sg-${color}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={color} stopOpacity={0.3} />
            <stop offset="95%" stopColor={color} stopOpacity={0}   />
          </linearGradient>
        </defs>
        <Area type="monotone" dataKey="v" stroke={color} strokeWidth={1.5} fill={`url(#sg-${color})`} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

// ─────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────
export default function DashboardPage() {
  // FIX: useTenant requires a tenantId argument — pass empty string as default
  // so TypeScript is satisfied; the hook will resolve the real value internally.
  const { tenantId } = useTenant();
  const [m,           setM]           = useState<Metrics | null>(null);
  const [loading,     setLoading]     = useState(true);
  const [refreshing,  setRefreshing]  = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [liveCount,   setLiveCount]   = useState(0);

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    try {
      const res  = await fetch("/api/dashboard/metrics");
      const data = await res.json();
      setM(data);
      setLastUpdated(new Date().toISOString());
    } catch (e) {
      console.error("Dashboard metrics failed:", e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Auto-refresh every 60 seconds
  useEffect(() => {
    const iv = setInterval(() => load(true), 60000);
    return () => clearInterval(iv);
  }, [load]);

  // Realtime subscriptions
  useEffect(() => {
    const ch = supabase.channel("dashboard-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "candidates" },      () => { setLiveCount(n => n + 1); load(true); })
      .on("postgres_changes", { event: "*", schema: "public", table: "onboarding" },      () => load(true))
      .on("postgres_changes", { event: "*", schema: "public", table: "compliance_docs" }, () => load(true))
      .on("postgres_changes", { event: "*", schema: "public", table: "incidents" },       () => load(true))
      .on("postgres_changes", { event: "*", schema: "public", table: "tasks" },           () => load(true))
      .on("postgres_changes", { event: "*", schema: "public", table: "spotlights" },      () => load(true))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [load]);

  if (loading) return (
    <div className="flex items-center justify-center h-[60vh] gap-2 text-zinc-500 text-sm">
      <Loader2 size={16} className="animate-spin" /> Loading dashboard...
    </div>
  );

  if (!m) return (
    <div className="flex items-center justify-center h-[60vh] text-red-400 text-sm">
      Failed to load metrics. Check your API route.
    </div>
  );

  const weekLabels   = ["W-5","W-4","W-3","W-2","W-1","Now"];
  const appTrendData = m.trends.applications.map((v, i) => ({ name: weekLabels[i], Applications: v, Hires: m.trends.hires[i] }));

  return (
    <div className="p-4 md:p-6 space-y-6">
      <SpotlightOfMonthBanner />

      {/* ── PAGE HEADER ── */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Overview</h1>
          <p className="text-zinc-500 text-sm mt-0.5">
            Workforce Intelligence · Xavier AI active
            {liveCount > 0 && (
              <span className="ml-2 text-indigo-400">· {liveCount} live update{liveCount > 1 ? "s" : ""}</span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full border
            ${m.systemHealth === "Healthy" ? "border-emerald-500/25 bg-emerald-500/10 text-emerald-400" :
              m.systemHealth === "At Risk"  ? "border-amber-500/25 bg-amber-500/10 text-amber-400"      :
                                              "border-red-500/25 bg-red-500/10 text-red-400"}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${
              m.systemHealth === "Healthy" ? "bg-emerald-400 animate-pulse" :
              m.systemHealth === "At Risk" ? "bg-amber-400"                 : "bg-red-400 animate-pulse"}`} />
            {m.systemHealth}
          </div>
          <button
            onClick={() => load(true)}
            disabled={refreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-zinc-800 text-xs text-zinc-400 hover:text-white hover:border-zinc-700 transition"
          >
            <RefreshCw size={12} className={refreshing ? "animate-spin" : ""} />
            {lastUpdated ? timeAgo(lastUpdated) : "Refresh"}
          </button>
        </div>
      </div>

      {/* ── XAVIER ANALYTICS STRIP ── */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Brain size={14} className="text-indigo-400" />
          <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">Xavier AI Analytics</span>
          <span className="text-[10px] text-zinc-600 ml-auto">Live · updates on every event</span>
        </div>
        <XavierStrip m={m} />
      </div>

      {/* ── KPI STRIP ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <KPICard label="Total Applied"    value={m.applied}                  sub="All time"                                             icon={Users}         color="bg-indigo-600"                                                    trend="up"                                    />
        <KPICard label="In Pipeline"      value={m.screening + m.interview}  sub="Active candidates"                                    icon={Activity}      color="bg-blue-600"                                                      trend="flat"                                  />
        <KPICard label="Interview Stage"  value={m.interview}                sub="Awaiting decision"                                    icon={Target}        color="bg-purple-600"                                                    trend="up"                                    />
        <KPICard label="Hired"            value={m.hired}                    sub="Placements closed"                                    icon={Award}         color="bg-emerald-600"                                                   trend="up"                                    />
        <KPICard label="Time to Hire"     value={m.timeToHire.current ?? 0}  sub={m.timeToHire.current == null ? "Not tracked yet" : `Avg over ${m.timeToHire.sampleSize} hire${m.timeToHire.sampleSize === 1 ? "" : "s"}`} icon={Clock} color="bg-teal-600" trend="flat" decimals={1} suffix="d" />
        <KPICard label="Avg Xavier Score" value={m.avgScore}                 sub="Across all applications"                              icon={TrendingUp}    color="bg-amber-600"    trend="flat"  suffix="/100"                     />
        <KPICard label="Open Tasks"       value={m.openTasks ?? 0}           sub="Pending action"                                       icon={Briefcase}     color="bg-orange-600"   trend={m.openTasks > 10 ? "up" : "flat"}      />
        <KPICard label="Active Incidents" value={m.activeIncidents}          sub="PivotSOS"                                             icon={AlertTriangle} color={m.activeIncidents > 0 ? "bg-red-600" : "bg-zinc-700"} trend={m.activeIncidents > 0 ? "up" : "flat"} />
      </div>

      {/* ── PIPELINE + XAVIER INTELLIGENCE ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Department Pipeline Distribution */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <h2 className="text-sm font-semibold text-white mb-1">Pipeline by Department</h2>
          <p className="text-xs text-zinc-600 mb-4">Candidate distribution across specialties</p>
          <div className="flex items-center gap-4">
            {/* Donut — guarded so container has size before Recharts measures */}
            <div className="w-40 h-40 flex-shrink-0" style={{ minWidth: 0 }}>
              <ChartReady height={160}>
                <ResponsiveContainer width="100%" height={160}>
                  <PieChart>
                    <Pie
                      data={m.deptDistribution}
                      dataKey="value"
                      outerRadius={60}
                      innerRadius={36}
                      paddingAngle={3}
                      startAngle={90}
                      endAngle={-270}
                    >
                      {m.deptDistribution.map((_, i) => (
                        <Cell key={i} fill={DEPT_COLORS[i % DEPT_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<ChartTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </ChartReady>
            </div>
            {/* Legend */}
            <div className="flex-1 space-y-2 min-w-0">
              {m.deptDistribution.map((d, i) => {
                const pct = m.applied > 0 ? Math.round((d.value / m.applied) * 100) : 0;
                return (
                  <div key={d.name} className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: DEPT_COLORS[i % DEPT_COLORS.length] }} />
                    <span className="text-xs text-zinc-400 flex-1 truncate">{d.name}</span>
                    <span className="text-xs font-semibold text-white">{d.value}</span>
                    <span className="text-[10px] text-zinc-600 w-8 text-right">{pct}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Xavier Intelligence */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <div className="flex items-center gap-2 mb-4">
            <Brain size={15} className="text-indigo-400" />
            <h2 className="text-sm font-semibold text-white">Xavier Intelligence</h2>
            <span className="text-[10px] text-zinc-600 ml-auto">Live insights</span>
            {m.insights.length > 0 && (
              <ReportAIContent
                surface="xavier_insight"
                content={m.insights.map((i) => i.message).join(" | ")}
              />
            )}
          </div>
          <div className="space-y-3">
            {m.insights.map((ins, i) => {
              const cfg = SEVERITY_CFG[ins.severity] ?? SEVERITY_CFG.info;
              return (
                <div key={i} className="flex items-start gap-2.5">
                  <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1.5 ${cfg.dot}`} />
                  <p className={`text-xs leading-relaxed ${cfg.cls}`}>{ins.message}</p>
                </div>
              );
            })}
            {m.insights.length === 0 && (
              <p className="text-xs text-zinc-600 text-center py-4">No insights yet — submit applications to activate Xavier AI analysis</p>
            )}
          </div>
          <div className={`mt-4 flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-medium
            ${m.systemHealth === "Healthy" ? "border-emerald-500/20 bg-emerald-500/5 text-emerald-400" :
              m.systemHealth === "At Risk"  ? "border-amber-500/20 bg-amber-500/5 text-amber-400"      :
                                              "border-red-500/20 bg-red-500/5 text-red-400"}`}>
            <ShieldCheck size={12} />
            System {m.systemHealth} · {m.activeIncidents > 0 ? `${m.activeIncidents} incident${m.activeIncidents > 1 ? "s" : ""} active` : "No active incidents"}
          </div>
        </div>
      </div>

      {/* ── HIRING FUNNEL + TRENDS ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

        {/* Hiring Funnel */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <h2 className="text-sm font-semibold text-white mb-1">Hiring Funnel</h2>
          <p className="text-xs text-zinc-600 mb-4">Drop-off rate at each stage</p>
          <FunnelBar label="Applied"   value={m.funnel.applied}   max={m.funnel.applied} color="bg-indigo-500"  />
          <FunnelBar label="Screening" value={m.funnel.screening} max={m.funnel.applied} color="bg-blue-500"    />
          <FunnelBar label="Interview" value={m.funnel.interview} max={m.funnel.applied} color="bg-purple-500"  />
          <FunnelBar label="Offer"     value={m.funnel.offer}     max={m.funnel.applied} color="bg-amber-500"   />
          <FunnelBar label="Hired"     value={m.funnel.hired}     max={m.funnel.applied} color="bg-emerald-500" />
          <div className="mt-4 pt-3 border-t border-zinc-800 flex justify-between text-xs">
            <span className="text-zinc-600">Conversion</span>
            <span className={`font-semibold ${m.conversionRate > 15 ? "text-emerald-400" : "text-amber-400"}`}>
              {m.conversionRate}%
            </span>
          </div>
        </div>

        {/* Applications Trend */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <h2 className="text-sm font-semibold text-white mb-1">Application Trends</h2>
          <p className="text-xs text-zinc-600 mb-4">Last 6 weeks · applications vs hires</p>
          <ChartReady height={144}>
            <div className="h-36" style={{ minWidth: 0 }}>
              <ResponsiveContainer width="100%" height={144}>
                <AreaChart data={appTrendData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="appGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#818cf8" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#818cf8" stopOpacity={0}   />
                    </linearGradient>
                    <linearGradient id="hireGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#4ade80" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#4ade80" stopOpacity={0}   />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#52525b" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "#52525b" }} axisLine={false} tickLine={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Area type="monotone" dataKey="Applications" stroke="#818cf8" strokeWidth={2} fill="url(#appGrad)"  dot={false} />
                  <Area type="monotone" dataKey="Hires"        stroke="#4ade80" strokeWidth={2} fill="url(#hireGrad)" dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </ChartReady>
          <div className="flex gap-4 mt-2">
            <div className="flex items-center gap-1.5 text-[10px] text-zinc-500"><span className="w-2 h-0.5 bg-indigo-400 rounded" /> Applications</div>
            <div className="flex items-center gap-1.5 text-[10px] text-zinc-500"><span className="w-2 h-0.5 bg-emerald-400 rounded" /> Hires</div>
          </div>
        </div>


      </div>

      {/* ── TOP ROLES + COMPLIANCE ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Top Roles */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <h2 className="text-sm font-semibold text-white mb-1">Top Roles Applied</h2>
          <p className="text-xs text-zinc-600 mb-4">Most in-demand positions</p>
          {m.topRoles.length > 0 ? (
            <div className="space-y-3">
              {m.topRoles.map((r, i) => {
                const pct = m.applied > 0 ? (r.value / m.applied) * 100 : 0;
                return (
                  <div key={r.name}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-zinc-400 truncate max-w-[160px]">{r.name}</span>
                      <span className="text-white font-medium ml-2">{r.value}</span>
                    </div>
                    <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-1000"
                        style={{ width: `${pct}%`, background: DEPT_COLORS[i % DEPT_COLORS.length] }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-zinc-600 text-center py-4">No role data yet</p>
          )}
        </div>

        {/* Compliance Summary */}
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <h2 className="text-sm font-semibold text-white mb-1">Compliance Overview</h2>
          <p className="text-xs text-zinc-600 mb-4">Credential tracking status</p>
          <div className="flex items-center justify-center mb-4">
            <div className="relative w-28 h-28" style={{ minWidth: 0 }}>
              <ChartReady height={112}>
                <ResponsiveContainer width="100%" height={112}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Approved",  value: m.complianceRate },
                        { name: "Remaining", value: 100 - m.complianceRate },
                      ]}
                      dataKey="value"
                      outerRadius={50}
                      innerRadius={36}
                      startAngle={90}
                      endAngle={-270}
                      paddingAngle={0}
                    >
                      <Cell fill={m.complianceRate >= 70 ? "#4ade80" : "#f59e0b"} />
                      <Cell fill="#1f1f2e" />
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </ChartReady>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={`text-xl font-bold ${m.complianceRate >= 70 ? "text-emerald-400" : "text-amber-400"}`}>
                  {m.complianceRate}%
                </span>
                <span className="text-[9px] text-zinc-600">approved</span>
              </div>
            </div>
          </div>
          <div className="space-y-2">
            {[
              { label: "Onboarding Active", value: m.onboarding,           color: "text-blue-400"    },
              { label: "Compliance Rate",   value: `${m.complianceRate}%`, color: m.complianceRate >= 70 ? "text-emerald-400" : "text-amber-400" },
              { label: "Spotlight Posts",   value: m.spotlightsThisMonth,  color: "text-amber-400"   },
            ].map(({ label, value, color }) => (
              <div key={label} className="flex justify-between text-xs">
                <span className="text-zinc-500">{label}</span>
                <span className={`font-semibold ${color}`}>{value}</span>
              </div>
            ))}
          </div>
        </div>


      </div>

      {/* ── FOOTER ── */}
      <div className="flex items-center justify-between text-[10px] text-zinc-700 pt-2 border-t border-zinc-800/50">
        <span>PivotOps · Xavier AI Workforce Intelligence</span>
        <span>{lastUpdated ? `Last updated: ${timeAgo(lastUpdated)}` : "Loading..."}</span>
      </div>
    </div>
  );
}
