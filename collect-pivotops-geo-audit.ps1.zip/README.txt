﻿PIVOTOPS GEO AUDIT BUNDLE
=========================

Generated:
20260815-185240

Purpose:
This bundle contains the non-sensitive source/configuration information
required to audit and implement the PivotOps GEO / AI recommendation
architecture.

Excluded intentionally:
- .env files
- environment variable values
- API keys
- Supabase credentials
- service-role keys
- passwords
- node_modules
- .next
- .git
- build artifacts
- large media files

Important:
This bundle should be treated as source code and therefore should not
be shared publicly.

The project itself was NOT modified by this collection script.
