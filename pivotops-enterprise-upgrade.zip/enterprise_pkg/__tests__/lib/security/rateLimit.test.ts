// __tests__/lib/security/rateLimit.test.ts
import { describe, it, expect, beforeEach, vi } from "vitest";
import { checkRateLimit, RATE_LIMITS } from "../../../lib/security/rateLimit";

describe("checkRateLimit", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  it("allows requests within the limit", () => {
    const key = `test-ip:${Date.now()}`;
    const cfg = { limit: 3, windowSec: 60 };

    const r1 = checkRateLimit(key, cfg);
    const r2 = checkRateLimit(key, cfg);
    const r3 = checkRateLimit(key, cfg);

    expect(r1.allowed).toBe(true);
    expect(r2.allowed).toBe(true);
    expect(r3.allowed).toBe(true);
    expect(r3.remaining).toBe(0);
  });

  it("blocks requests over the limit", () => {
    const key = `test-block:${Date.now()}`;
    const cfg = { limit: 2, windowSec: 60 };

    checkRateLimit(key, cfg);
    checkRateLimit(key, cfg);
    const r3 = checkRateLimit(key, cfg);

    expect(r3.allowed).toBe(false);
    expect(r3.remaining).toBe(0);
  });

  it("resets after the window expires", () => {
    const key = `test-reset:${Date.now()}`;
    const cfg = { limit: 1, windowSec: 10 };

    checkRateLimit(key, cfg);
    const blocked = checkRateLimit(key, cfg);
    expect(blocked.allowed).toBe(false);

    // Advance time past the window
    vi.advanceTimersByTime(11_000);

    const reset = checkRateLimit(key, cfg);
    expect(reset.allowed).toBe(true);
  });

  it("exposes correct resetAt timestamp", () => {
    const key = `test-reset-at:${Date.now()}`;
    const cfg = { limit: 5, windowSec: 30 };
    const before = Date.now();

    const result = checkRateLimit(key, cfg);

    expect(result.resetAt).toBeGreaterThan(before);
    expect(result.resetAt).toBeLessThanOrEqual(before + 30_000 + 100);
  });

  it("RATE_LIMITS presets have sensible values", () => {
    expect(RATE_LIMITS.public.limit).toBeLessThanOrEqual(20);
    expect(RATE_LIMITS.auth.limit).toBeLessThanOrEqual(10);
    expect(RATE_LIMITS.authenticated.limit).toBeGreaterThan(RATE_LIMITS.public.limit);
  });
});
