// __tests__/lib/security/schemas.test.ts
import { describe, it, expect } from "vitest";
import {
  ApplySchema,
  CandidateActionSchema,
  IncidentSchema,
  OnboardingSchema,
  ComplianceRemindSchema,
  SpotlightApproveSchema,
} from "../../../lib/security/schemas";

// ─────────────────────────────────────────
// ApplySchema
// ─────────────────────────────────────────
describe("ApplySchema", () => {
  const valid = {
    name:  "Jane Smith",
    email: "jane@example.com",
    role:  "Registered Nurse",
  };

  it("accepts a minimal valid payload", () => {
    expect(ApplySchema.safeParse(valid).success).toBe(true);
  });

  it("rejects missing name", () => {
    const result = ApplySchema.safeParse({ ...valid, name: "" });
    expect(result.success).toBe(false);
  });

  it("rejects invalid email", () => {
    const result = ApplySchema.safeParse({ ...valid, email: "not-an-email" });
    expect(result.success).toBe(false);
  });

  it("rejects missing role", () => {
    const result = ApplySchema.safeParse({ ...valid, role: "" });
    expect(result.success).toBe(false);
  });

  it("coerces years_experience to number", () => {
    const result = ApplySchema.safeParse({ ...valid, years_experience: "5" });
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.years_experience).toBe(5);
  });

  it("rejects negative years_experience", () => {
    const result = ApplySchema.safeParse({ ...valid, years_experience: -1 });
    expect(result.success).toBe(false);
  });

  it("defaults tenant_id to 'default'", () => {
    const result = ApplySchema.safeParse(valid);
    if (result.success) expect(result.data.tenant_id).toBe("default");
  });
});

// ─────────────────────────────────────────
// CandidateActionSchema
// ─────────────────────────────────────────
describe("CandidateActionSchema", () => {
  const validId = "123e4567-e89b-12d3-a456-426614174000";

  it("accepts valid action", () => {
    const result = CandidateActionSchema.safeParse({ candidateId: validId, action: "approve" });
    expect(result.success).toBe(true);
  });

  it("rejects unknown action", () => {
    const result = CandidateActionSchema.safeParse({ candidateId: validId, action: "delete_everything" });
    expect(result.success).toBe(false);
  });

  it("rejects invalid UUID", () => {
    const result = CandidateActionSchema.safeParse({ candidateId: "not-a-uuid", action: "approve" });
    expect(result.success).toBe(false);
  });
});

// ─────────────────────────────────────────
// IncidentSchema
// ─────────────────────────────────────────
describe("IncidentSchema", () => {
  it("accepts a valid create payload", () => {
    const result = IncidentSchema.safeParse({ action: "create", title: "Server down", severity: "critical" });
    expect(result.success).toBe(true);
  });

  it("rejects create with empty title", () => {
    const result = IncidentSchema.safeParse({ action: "create", title: "" });
    expect(result.success).toBe(false);
  });

  it("accepts acknowledge action", () => {
    const result = IncidentSchema.safeParse({
      action:     "acknowledge",
      incidentId: "123e4567-e89b-12d3-a456-426614174000",
      userId:     "user-123",
    });
    expect(result.success).toBe(true);
  });

  it("rejects unknown action", () => {
    const result = IncidentSchema.safeParse({ action: "nuke" });
    expect(result.success).toBe(false);
  });

  it("defaults severity to medium", () => {
    const result = IncidentSchema.safeParse({ action: "create", title: "Test" });
    if (result.success && result.data.action === "create") {
      expect(result.data.severity).toBe("medium");
    }
  });
});

// ─────────────────────────────────────────
// OnboardingSchema
// ─────────────────────────────────────────
describe("OnboardingSchema", () => {
  it("accepts valid UUID", () => {
    const result = OnboardingSchema.safeParse({ candidateId: "123e4567-e89b-12d3-a456-426614174000" });
    expect(result.success).toBe(true);
  });

  it("rejects invalid UUID", () => {
    const result = OnboardingSchema.safeParse({ candidateId: "bad-id" });
    expect(result.success).toBe(false);
  });
});

// ─────────────────────────────────────────
// ComplianceRemindSchema
// ─────────────────────────────────────────
describe("ComplianceRemindSchema", () => {
  const validId = "123e4567-e89b-12d3-a456-426614174000";

  it("accepts valid payload", () => {
    const result = ComplianceRemindSchema.safeParse({
      candidateId: validId,
      docTypes: ["nursing_license", "flu_shot"],
    });
    expect(result.success).toBe(true);
  });

  it("rejects empty docTypes array", () => {
    const result = ComplianceRemindSchema.safeParse({ candidateId: validId, docTypes: [] });
    expect(result.success).toBe(false);
  });
});

// ─────────────────────────────────────────
// SpotlightApproveSchema
// ─────────────────────────────────────────
describe("SpotlightApproveSchema", () => {
  const validId = "123e4567-e89b-12d3-a456-426614174000";

  it("accepts approved=true", () => {
    const result = SpotlightApproveSchema.safeParse({ spotlightId: validId, approved: true });
    expect(result.success).toBe(true);
  });

  it("accepts approved=false", () => {
    const result = SpotlightApproveSchema.safeParse({ spotlightId: validId, approved: false });
    expect(result.success).toBe(true);
  });

  it("rejects missing approved field", () => {
    const result = SpotlightApproveSchema.safeParse({ spotlightId: validId });
    expect(result.success).toBe(false);
  });
});
