// __tests__/lib/security/withSecurity.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest";
import { NextRequest } from "next/server";
import { z } from "zod";
import { withSecurity } from "../../../lib/security/withSecurity";
import { RATE_LIMITS } from "../../../lib/security/rateLimit";

// Mock validateSession
vi.mock("../../../lib/security/apiAuth", () => ({
  validateSession: vi.fn(),
  getClientIp: vi.fn(() => "127.0.0.1"),
}));

import { validateSession } from "../../../lib/security/apiAuth";

function makeRequest(body?: unknown, method = "POST", ip = "1.2.3.4") {
  const req = new NextRequest("http://localhost:3000/api/test", {
    method,
    headers: {
      "content-type": "application/json",
      "x-forwarded-for": ip,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  return req;
}

const TestSchema = z.object({
  name: z.string().min(1),
  age:  z.coerce.number().min(0),
});

describe("withSecurity", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns 401 when auth required and no session", async () => {
    vi.mocked(validateSession).mockResolvedValue(null);

    const handler = withSecurity(async () => {
      return new Response("ok");
    }, { requireAuth: true, rateLimit: { limit: 100, windowSec: 60 } });

    const res = await handler(makeRequest({ name: "test", age: 1 }));
    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.error).toMatch(/authentication/i);
  });

  it("passes through when auth not required", async () => {
    const { NextResponse } = await import("next/server");
    const handler = withSecurity(
      async () => NextResponse.json({ ok: true }),
      { requireAuth: false, rateLimit: { limit: 100, windowSec: 60 } }
    );

    const res = await handler(makeRequest({ name: "test", age: 1 }));
    expect(res.status).toBe(200);
  });

  it("returns 422 on schema validation failure", async () => {
    const { NextResponse } = await import("next/server");
    const handler = withSecurity(
      async () => NextResponse.json({ ok: true }),
      {
        schema:      TestSchema,
        requireAuth: false,
        rateLimit:   { limit: 100, windowSec: 60 },
      }
    );

    const res = await handler(makeRequest({ name: "", age: -1 }, "POST", "9.9.9.1"));
    expect(res.status).toBe(422);
    const body = await res.json();
    expect(body.issues).toBeDefined();
    expect(Array.isArray(body.issues)).toBe(true);
  });

  it("returns 429 when rate limit exceeded", async () => {
    const { NextResponse } = await import("next/server");
    const uniqueIp = `10.0.0.${Math.floor(Math.random() * 255)}`;

    const handler = withSecurity(
      async () => NextResponse.json({ ok: true }),
      { requireAuth: false, rateLimit: { limit: 2, windowSec: 60 } }
    );

    await handler(makeRequest(undefined, "GET", uniqueIp));
    await handler(makeRequest(undefined, "GET", uniqueIp));
    const res = await handler(makeRequest(undefined, "GET", uniqueIp));

    expect(res.status).toBe(429);
    expect(res.headers.get("Retry-After")).toBeTruthy();
  });

  it("returns 403 when role requirement not met", async () => {
    vi.mocked(validateSession).mockResolvedValue({
      userId:   "user-1",
      tenantId: "t1",
      role:     "employee",
      email:    "test@test.com",
    });

    const { NextResponse } = await import("next/server");
    const handler = withSecurity(
      async () => NextResponse.json({ ok: true }),
      {
        requireAuth:  true,
        requireRole:  ["admin", "manager"],
        rateLimit:    { limit: 100, windowSec: 60 },
      }
    );

    const res = await handler(makeRequest(undefined, "GET", "5.5.5.5"));
    expect(res.status).toBe(403);
  });

  it("returns 400 on invalid JSON body", async () => {
    const { NextResponse } = await import("next/server");
    const handler = withSecurity(
      async () => NextResponse.json({ ok: true }),
      {
        schema:      TestSchema,
        requireAuth: false,
        rateLimit:   { limit: 100, windowSec: 60 },
      }
    );

    const req = new NextRequest("http://localhost:3000/api/test", {
      method:  "POST",
      headers: { "content-type": "application/json", "x-forwarded-for": "3.3.3.3" },
      body:    "not-valid-json",
    });

    const res = await handler(req);
    expect(res.status).toBe(400);
  });

  it("passes validated body to handler", async () => {
    const { NextResponse } = await import("next/server");
    let receivedBody: unknown;

    const handler = withSecurity<z.infer<typeof TestSchema>>(
      async (_req, { body }) => {
        receivedBody = body;
        return NextResponse.json({ ok: true });
      },
      {
        schema:      TestSchema,
        requireAuth: false,
        rateLimit:   { limit: 100, windowSec: 60 },
      }
    );

    await handler(makeRequest({ name: "Alice", age: "30" }, "POST", "7.7.7.7"));
    expect(receivedBody).toEqual({ name: "Alice", age: 30 });
  });
});
