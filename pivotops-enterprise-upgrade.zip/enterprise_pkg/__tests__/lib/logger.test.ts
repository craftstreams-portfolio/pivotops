// __tests__/lib/logger.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest";

describe("logger", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it("calls console.info for info level", async () => {
    const spy = vi.spyOn(console, "info").mockImplementation(() => {});
    // Re-import to bypass the vi.mock in setup.ts for this specific test
    const { logger } = await import("../../lib/logger");
    logger.info("test message", { userId: "abc" });
    expect(spy).toHaveBeenCalledOnce();
    const call = spy.mock.calls[0][0] as string;
    const parsed = JSON.parse(call);
    expect(parsed.level).toBe("info");
    expect(parsed.message).toBe("test message");
    expect(parsed.userId).toBe("abc");
    expect(parsed.service).toBe("pivotops");
    expect(parsed.timestamp).toBeTruthy();
  });

  it("calls console.error for error level", async () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    const { logger } = await import("../../lib/logger");
    logger.error("something broke", { error: "oops" });
    expect(spy).toHaveBeenCalledOnce();
    const parsed = JSON.parse(spy.mock.calls[0][0] as string);
    expect(parsed.level).toBe("error");
  });

  it("calls console.warn for warn level", async () => {
    const spy = vi.spyOn(console, "warn").mockImplementation(() => {});
    const { logger } = await import("../../lib/logger");
    logger.warn("rate limit hit");
    expect(spy).toHaveBeenCalledOnce();
  });

  it("calls console.debug for debug level", async () => {
    const spy = vi.spyOn(console, "debug").mockImplementation(() => {});
    const { logger } = await import("../../lib/logger");
    logger.debug("debug info");
    expect(spy).toHaveBeenCalledOnce();
  });

  it("includes all meta fields in output", async () => {
    const spy = vi.spyOn(console, "info").mockImplementation(() => {});
    const { logger } = await import("../../lib/logger");
    logger.info("test", { tenantId: "t1", route: "/api/test", count: 5 });
    const parsed = JSON.parse(spy.mock.calls[0][0] as string);
    expect(parsed.tenantId).toBe("t1");
    expect(parsed.route).toBe("/api/test");
    expect(parsed.count).toBe(5);
  });
});
