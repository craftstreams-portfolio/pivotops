// __tests__/setup.ts
// Global test setup for PivotOps

// Mock environment variables
process.env.NEXT_PUBLIC_SUPABASE_URL     = "https://test.supabase.co";
process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = "test-anon-key";
process.env.SUPABASE_SERVICE_ROLE_KEY     = "test-service-role-key";
process.env.NEXT_PUBLIC_APP_URL           = "http://localhost:3000";
process.env.NODE_ENV                      = "test";

// Silence logger output in tests
vi.mock("../lib/logger", () => ({
  logger: {
    debug: vi.fn(),
    info:  vi.fn(),
    warn:  vi.fn(),
    error: vi.fn(),
  },
}));
