// vitest.config.ts
import { defineConfig } from "vitest/config";
import path from "path";

export default defineConfig({
  test: {
    globals:     true,
    environment: "node",
    setupFiles:  ["./__tests__/setup.ts"],
    coverage: {
      provider:  "v8",
      reporter:  ["text", "json", "html"],
      include:   ["lib/**/*.ts", "app/api/**/*.ts"],
      exclude:   ["**/*.d.ts", "**/node_modules/**"],
      thresholds: {
        lines:     60,
        functions: 60,
        branches:  50,
      },
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "."),
    },
  },
});
