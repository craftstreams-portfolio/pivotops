/**
 * lib/security/rateLimit.ts
 * In-memory sliding-window rate limiter.
 * Works with no Redis dependency — safe for Vercel serverless.
 * For multi-instance prod, swap the store for an Upstash Redis adapter.
 */

interface WindowEntry {
  count: number;
  resetAt: number;
}

const store = new Map<string, WindowEntry>();

// Clean up expired entries every 5 minutes
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of store.entries()) {
      if (entry.resetAt < now) store.delete(key);
    }
  }, 5 * 60 * 1000);
}

export interface RateLimitConfig {
  /** Max requests per window */
  limit: number;
  /** Window size in seconds */
  windowSec: number;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
}

/**
 * Check and increment rate limit for a given key (e.g. IP + route).
 * Returns allowed=false when the limit is exceeded.
 */
export function checkRateLimit(
  key: string,
  config: RateLimitConfig
): RateLimitResult {
  const now = Date.now();
  const windowMs = config.windowSec * 1000;

  let entry = store.get(key);

  if (!entry || entry.resetAt < now) {
    entry = { count: 1, resetAt: now + windowMs };
    store.set(key, entry);
    return { allowed: true, remaining: config.limit - 1, resetAt: entry.resetAt };
  }

  entry.count++;
  store.set(key, entry);

  const remaining = Math.max(0, config.limit - entry.count);
  return {
    allowed: entry.count <= config.limit,
    remaining,
    resetAt: entry.resetAt,
  };
}

/** Pre-configured limiters for each route tier */
export const RATE_LIMITS = {
  /** Public-facing endpoints — e.g. candidate apply */
  public: { limit: 10, windowSec: 60 },
  /** Authenticated API endpoints */
  authenticated: { limit: 120, windowSec: 60 },
  /** Auth endpoints — stricter */
  auth: { limit: 5, windowSec: 60 },
  /** Webhooks / internal workers */
  internal: { limit: 500, windowSec: 60 },
} satisfies Record<string, RateLimitConfig>;
